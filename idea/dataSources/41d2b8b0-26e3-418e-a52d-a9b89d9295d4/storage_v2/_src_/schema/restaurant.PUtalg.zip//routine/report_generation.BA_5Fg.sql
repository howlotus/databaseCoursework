create
    definer = root@localhost procedure report_generation(IN r_year int, IN r_month int)
BEGIN
declare r_dish_name varchar(45);
declare r_quantity, r_revenue integer;
declare done integer default 0;

declare cur1 cursor for
	Select Dish_Name, sum(Dish_Quantity) as month_quantity, sum(Dish_Quantity) * Dish_Price as month_revenue
    from (restaurant.dish join restaurant.order_line using (Dish_ID)) join restaurant.order using (Order_ID)
    where year(Order_Date_Time) = r_year and month(Order_Date_Time) = r_month
    group by Dish_Name;
    
declare continue handler for
SQLSTATE '02000' set done = 1;

open cur1;

WHILE done = 0 DO
	FETCH cur1 INTO r_dish_name, r_quantity, r_revenue;
    IF done = 0 THEN
		INSERT dish_popularity (Year, Month, Dish_Name, Month_Quantity, Month_Revenue)
        VALUES (r_year, r_month, r_dish_name, r_quantity, r_revenue);
	END IF;
END WHILE;

close cur1;
END;

