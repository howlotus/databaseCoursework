create view vt1 as
select `restaurant`.`dish`.`Dish_ID` AS `Dish_ID`, sum(`restaurant`.`order_line`.`Dish_Quantity`) AS `dish_sum`
from (`restaurant`.`dish`
         join (`restaurant`.`order_line` join (select `restaurant`.`order`.`Order_ID`        AS `Order_ID`,
                                                      `restaurant`.`order`.`Order_Date_Time` AS `Order_Date_Time`,
                                                      `restaurant`.`order`.`Order_Cost`      AS `Order_Cost`,
                                                      `restaurant`.`order`.`Waiter_ID`       AS `Waiter_ID`
                                               from `restaurant`.`order`
                                               where ((year(`restaurant`.`order`.`Order_Date_Time`) = 2013) and
                                                      (month(`restaurant`.`order`.`Order_Date_Time`) = 4))) `sel1` on ((`restaurant`.`order_line`.`Order_ID` = `sel1`.`Order_ID`)))
              on ((`restaurant`.`dish`.`Dish_ID` = `restaurant`.`order_line`.`Dish_ID`)))
group by `restaurant`.`dish`.`Dish_Name`;

